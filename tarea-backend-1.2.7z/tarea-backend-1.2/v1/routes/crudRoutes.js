const express = require('express');
const router = express.Router();
const crudController = require('../../controllers/crudController');


router
    .get('/', crudController.getAllCrud)
    .get('/:crudID', crudController.getOneCrud)
    .post('/', crudController.createNewCrud)
    .patch('/:crudID', crudController.updateOneCrud)
    .delete('/:crudID', crudController.deleteOneCrud)

module.exports = router;
const express = require('express');
const v1CrudRouter = require('./v1/routes/crudRoutes');

const app = express();

app.use(express.json());
app.use('/api/v1/crud', v1CrudRouter);



app.listen(process.env.PORT, () => {
    console.log(`Server listening on port: ${process.env.PORT}`);
})
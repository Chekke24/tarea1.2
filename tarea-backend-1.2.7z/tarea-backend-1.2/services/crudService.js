const { v4 : uuid} = require('uuid');
const Crud = require('../data/Crud');

const getAllCrud = () => {
    const allCrud = Crud.getAllCrud();
    return allCrud;
};

const getOneCrud = (crudID) => {
    const crud = Crud.getOneCrud(crudID);
    return crud;
};

const createNewCrud = (newCrud) => {
    const crudToInsert = {
        ...newCrud,
        ID: uuid(),
        createdCr: new Date().toLocaleString('Arg', { timeZone: 'UTC-3' }),
        updatedCr: new Date().toLocaleString('Arg', { timeZone: 'UTC-3' }),
    };
    
    const createdCrud = Crud.createNewCrud(crudToInsert);
    return createdCrud;
};

const updateOneCrud = (crudID, changes) => {
    const updatedCrud = Crud.updateOneCrud(crudID, changes);
    return updatedCrud;
};

const deleteOneCrud = (crudID) => {
    Crud.deleteOneCrud(crudID);

}

module.exports = { getAllCrud, getOneCrud, createNewCrud, updateOneCrud, deleteOneCrud};
const crudService = require('../services/crudService');

const getAllCrud = (req, res) => {
    const allCrud = crudService.getAllCrud();
    res.send({ status: "Ok", data: allCrud });
};

const getOneCrud = (req ,res) => {
    const {
        params: { crudID },
    } = req;
    if (!crudID){
        return;
    }
    const crud = crud.Service.getOneCrud(crudID);
    res.send({ status: "Ok", data: crud })
};

const createNewCrud = (req, res) => {
    const { body } = req;

    if ( !body.ID || !body.Nombre|| !body.Apellido || !body.DNI) {
        return;
    }

    const newCrud = {
        ID: body.ID,
        Nombre: body.Nombre,
        Apellido: body.Apellido,
        DNI: body.DNI,

    }

    const createdCrud = crudService.createNewCrud(newCrud);
    res.status(201).send({ status: "Ok", data: createdCrud });
    
}

const updateOneCrud = (req, res) => {
    const { body,  params : { crudID }, } = req;

    if (!crudID){
        return;
    }

    const updatedCrud = crud.Service.updateOneCrud(crudID, body);
    res.send({ status: "Ok", data: updatedCrud });
}

const deleteOneCrud = (req, res) => {
    const { params : { crudID }, } = req;

    if (!crudID){
        return;
    }

    crudService.deleteOneCrud(crudID);
    res.status(204).send({ status: "Ok" });
}

module.exports = { getAllCrud, getOneCrud, createNewCrud, updateOneCrud, deleteOneCrud};
const fs = require('fs');

const saveToData = (data) => {
    fs.writeFileSync('./data/data.json', JSON.stringify(data, null, 2), {
    encoding: 'utf8'});
}

module.exports = {saveToData};